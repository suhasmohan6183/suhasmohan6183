﻿using Microsoft.AspNetCore.Identity;

namespace PetsAlone.Core
{
    public class ApplicationUser : IdentityUser
    {
    }
}
