namespace PetsAlone.Angular.Models
{
    public class AuthenticationInfo
    {
        public string Token { get; set; }
    }
}