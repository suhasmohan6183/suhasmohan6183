export class PetDetail {
  id: number;
  name: string;
  petType: number;
  displayPetType: string;
  missingSince: string;
  displayMissingSince: string;
}
