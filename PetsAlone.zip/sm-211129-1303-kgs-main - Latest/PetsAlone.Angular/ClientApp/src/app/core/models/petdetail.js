"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PetDetail = void 0;
var PetDetail = /** @class */ (function () {
    function PetDetail() {
    }
    return PetDetail;
}());
exports.PetDetail = PetDetail;
//# sourceMappingURL=petdetail.js.map