﻿using BusinessEntities;
using BusinessService;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.IO;

namespace TigerCard
{
    class Program
    {
        private static IServiceProvider _serviceProvider;
        static void Main(string[] args)
        {
            RegisterServices();

            var FareCalculatorService = _serviceProvider.GetService<IFareCalculator>();

            AddZonesToFareCalculatorService(FareCalculatorService);

            if (File.Exists(args[0]))
            {
                string[] lines = File.ReadAllLines(args[0]);

                var TotalFare = FareCalculatorService.GetTotalFare(lines);
                Console.WriteLine("Total Fare: {0}", TotalFare);
                
            }

            DisposeServices();
        }

          private static void AddZonesToFareCalculatorService(IFareCalculator fareCalculatorService)
          {
            IPeakHourTimings PeakHourTimings = new PeakHourTimings(); 
            IFare Fare = new Fare();
            IFareCapping FareCapping = new FareCapping();

            Fare.AddPeakHourFares("Zone1", 30);
            Fare.AddPeakHourFares("Zone2", 35);
            Fare.AddNonPeakHourFares("Zone1", 25);
            Fare.AddNonPeakHourFares("Zone2", 30);

            FareCapping.AddDailyFareCap("Zone1", 100);
            FareCapping.AddDailyFareCap("Zone2", 120);
            FareCapping.AddWeeklyFareCap("Zone1", 500);
            FareCapping.AddWeeklyFareCap("Zone2", 600);

            fareCalculatorService.AddZone(new Zone1(PeakHourTimings, Fare, FareCapping));


            Fare = new Fare();
            FareCapping = new FareCapping();

            Fare.AddPeakHourFares("Zone2", 25);
            Fare.AddPeakHourFares("Zone1", 35);
            Fare.AddNonPeakHourFares("Zone2", 20);
            Fare.AddNonPeakHourFares("Zone1", 30);

            FareCapping.AddDailyFareCap("Zone2", 80);
            FareCapping.AddDailyFareCap("Zone1", 120);
            FareCapping.AddWeeklyFareCap("Zone2", 400);
            FareCapping.AddWeeklyFareCap("Zone1", 600);

            fareCalculatorService.AddZone(new Zone2(PeakHourTimings, Fare, FareCapping));
        }

        private static void RegisterServices()
        {
            var collection = new ServiceCollection();
            collection.AddScoped<IFareCalculator, FareCalculator>();
            

            _serviceProvider = collection.BuildServiceProvider();
        }

        private static void DisposeServices()
        {
            if (_serviceProvider == null)
            {
                return;
            }
            if (_serviceProvider is IDisposable)
            {
                ((IDisposable)_serviceProvider).Dispose();
            }
        }
    }
}
