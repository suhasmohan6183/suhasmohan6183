1). Input Format-

<Date(DD/MM/YYYY)> <Time(HH:MM- 24 hr Format)> <Zone1> <Zone2>

Sample Input-
1/10/2021 10:20 Zone1 Zone2 