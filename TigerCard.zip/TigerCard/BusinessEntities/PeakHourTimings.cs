﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities
{
    public class PeakHourTimings : IPeakHourTimings
    {
        public Dictionary<DayOfWeek, Dictionary<Time, Time>> PeakHourData { get; set; }

        public PeakHourTimings()
        {
            PeakHourData = new Dictionary<DayOfWeek, Dictionary<Time, Time>>();
            var peakhourtime = new Dictionary<Time, Time>();
            peakhourtime.Add(new Time("7:00"), new Time("10:30"));
            peakhourtime.Add(new Time("17:00"), new Time("20:00"));
            PeakHourData.Add(DayOfWeek.Monday, peakhourtime);
            PeakHourData.Add(DayOfWeek.Tuesday, peakhourtime);
            PeakHourData.Add(DayOfWeek.Wednesday, peakhourtime);
            PeakHourData.Add(DayOfWeek.Thursday, peakhourtime);
            PeakHourData.Add(DayOfWeek.Friday, peakhourtime);

            var newpeakhourtime = new Dictionary<Time, Time>();
            newpeakhourtime.Add(new Time("9:00"), new Time("11:00"));
            newpeakhourtime.Add(new Time("18:00"), new Time("22:00"));
            PeakHourData.Add(DayOfWeek.Saturday, newpeakhourtime);
            PeakHourData.Add(DayOfWeek.Sunday, newpeakhourtime);
        }

    }
}
