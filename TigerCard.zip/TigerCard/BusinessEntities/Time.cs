﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities
{
    public class Time
    {
        public int Hour { get; set; }

        public int Minutes { get; set; }

        public Time(string time)
        {
            var strtime = time.Split(':');
            int hour = Convert.ToInt32(strtime[0]);
            int minutes = Convert.ToInt32(strtime[1]);

            this.Hour = hour;
            this.Minutes = minutes;
        }

        public static bool IsValidTime(string time)
        {
            if (time.Contains(':'))
            {
                string[] strtime = time.Split(':');
                if (strtime.Length == 2)
                {
                    int hour = Convert.ToInt32(strtime[0]);
                    int minutes = Convert.ToInt32(strtime[1]);

                    if (hour >= 24 || hour < 0 || minutes < 0 || minutes >= 60)
                        return false;
                    return true;
                }
                else
                    return false;
            }
            else
                return false;
        }

        public static bool operator <(Time ltime, Time rtime)
        {
            if ((ltime.Hour < rtime.Hour) ||
                (ltime.Hour == rtime.Hour && ltime.Minutes < rtime.Minutes))
                return true;

            return false;
        }

        public static bool operator >(Time ltime, Time rtime)
        {
            if ((ltime.Hour > rtime.Hour) ||
                (ltime.Hour == rtime.Hour && ltime.Minutes > rtime.Minutes))
                return true;

            return false;
        }

        public static bool operator <=(Time ltime, Time rtime)
        {
            if (((ltime.Hour < rtime.Hour) ||
                (ltime.Hour == rtime.Hour && ltime.Minutes < rtime.Minutes)) ||
                (ltime.Hour == rtime.Hour && ltime.Minutes == rtime.Minutes))
                return true;

            return false;
        }
        public static bool operator >=(Time ltime, Time rtime)
        {
            if (((ltime.Hour > rtime.Hour) ||
                (ltime.Hour == rtime.Hour && ltime.Minutes > rtime.Minutes)) ||
                (ltime.Hour == rtime.Hour && ltime.Minutes == rtime.Minutes))
                return true;

            return false;
        }
    }
}
