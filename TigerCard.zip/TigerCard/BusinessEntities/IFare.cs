﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities
{
    public interface IFare
    {
        Dictionary<string, int> PeakHourFares { get; set; }

         Dictionary<string, int> NonPeakHourFares { get; set; }
          void AddPeakHourFares(string ToZoneName, int Fare);

          void AddNonPeakHourFares(string ToZoneName, int Fare);

        void RemovePeakHourFares(string ToZoneName);

        void RemoveNonPeakHourFares(string ToZoneName);


        void UpdatePeakHourFares(string ToZoneName, int Fare);

        void UpdateNonPeakHourFares(string ToZoneName, int Fare);
    }
}
