﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities
{
    public interface IPeakHourTimings
    {
        Dictionary<DayOfWeek, Dictionary<Time, Time>> PeakHourData { get; set; }

    }
}
