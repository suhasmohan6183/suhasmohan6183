﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessEntities
{
    public abstract class Zone
    {
        public IPeakHourTimings PeakHourTimings { get; set; }

        public IFare Fares { get; set; }

        public IFareCapping FareCapping { get; set; }

        public abstract int GetFare(string date, string time, string toZone);

        

        public bool IsPeakHourTime(string date, string time)
        {
            var strdate = date.Split('/');
            var datetime = new DateTime(Convert.ToInt32(strdate[2]), Convert.ToInt32(strdate[1]), Convert.ToInt32(strdate[0]));
            Dictionary<Time, Time> PeakHourTime = this.PeakHourTimings.PeakHourData[datetime.DayOfWeek];

            var traveltime = new Time(time);
            return PeakHourTime.Where(x => x.Key <= traveltime && traveltime <= x.Value).Count() > 0;
        }
    }
}
