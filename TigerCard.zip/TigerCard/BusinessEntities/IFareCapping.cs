﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities
{
    public interface IFareCapping
    {
        Dictionary<string, int> DailyFareCap { get; set; }

        Dictionary<string, int> WeeklyFareCap { get; set; }
        void AddDailyFareCap(string ToZoneName, int Fare);

        void AddWeeklyFareCap(string ToZoneName, int Fare);

        void RemoveDailyFareCap(string ToZoneName);

        void RemoveWeeklyFareCap(string ToZoneName);


        void UpdateDailyFareCap(string ToZoneName, int Fare);

        void UpdateWeeklyFareCap(string ToZoneName, int Fare);
    }
}
