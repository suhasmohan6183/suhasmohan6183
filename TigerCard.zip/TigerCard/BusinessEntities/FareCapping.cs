﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities
{
    public class FareCapping : IFareCapping
    {
        public Dictionary<string, int> DailyFareCap { get; set; }
        public Dictionary<string, int> WeeklyFareCap { get; set; }

        public FareCapping()
        {
            DailyFareCap = new Dictionary<string, int>();
            WeeklyFareCap = new Dictionary<string, int>();
        }

        public void AddDailyFareCap(string ToZoneName, int FareCap)
        {
            DailyFareCap.Add(ToZoneName, FareCap);
        }

        public void AddWeeklyFareCap(string ToZoneName, int FareCap)
        {
            WeeklyFareCap.Add(ToZoneName, FareCap);
        }

        public void RemoveDailyFareCap(string ToZoneName)
        {
            DailyFareCap.Remove(ToZoneName);
        }

        public void RemoveWeeklyFareCap(string ToZoneName)
        {
            WeeklyFareCap.Remove(ToZoneName);
        }

        public void UpdateDailyFareCap(string ToZoneName, int FareCap)
        {
            DailyFareCap[ToZoneName] = FareCap;
        }

        public void UpdateWeeklyFareCap(string ToZoneName, int FareCap)
        {
            WeeklyFareCap[ToZoneName] = FareCap;
        }
    }
}
