﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities
{
    public class Fare : IFare
    {
        public Dictionary<string, int> PeakHourFares { get; set ; }
        public Dictionary<string, int> NonPeakHourFares { get; set; }


        public Fare()
        {
            PeakHourFares = new Dictionary<string, int>();
            NonPeakHourFares = new Dictionary<string, int>();
        }
        public void AddNonPeakHourFares(string ToZoneName, int Fare)
        {
            NonPeakHourFares.Add(ToZoneName, Fare);
        }

        public void AddPeakHourFares(string ToZoneName, int Fare)
        {
            PeakHourFares.Add(ToZoneName, Fare);
        }

        public void RemoveNonPeakHourFares(string ToZoneName)
        {
            NonPeakHourFares.Remove(ToZoneName);
        }

        public void RemovePeakHourFares(string ToZoneName)
        {
            PeakHourFares.Remove(ToZoneName);
        }

        public void UpdateNonPeakHourFares(string ToZoneName, int Fare)
        {
            NonPeakHourFares[ToZoneName] = Fare;
        }

        public void UpdatePeakHourFares(string ToZoneName, int Fare)
        {
            PeakHourFares[ToZoneName] = Fare;
        }
    }
}
