﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessEntities
{
    public class Zone2 : Zone
    {
        public Zone2(IPeakHourTimings peakhourtimings, IFare fare, IFareCapping fareCapping)
        {
            this.PeakHourTimings = peakhourtimings;
            this.Fares = fare;
            this.FareCapping = fareCapping;
        }

        public override int GetFare(string date, string time, string toZone)
        {
            if (IsPeakHourTime(date, time))
            {
                return this.Fares.PeakHourFares[toZone];
            }

            return this.Fares.NonPeakHourFares[toZone];
        }
    }
}
