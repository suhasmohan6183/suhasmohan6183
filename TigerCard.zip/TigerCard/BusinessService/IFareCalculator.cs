﻿using BusinessEntities;
using System;
using System.Collections.Generic;
using System.Text;

namespace BusinessService
{
    public interface IFareCalculator
    {
        int GetTotalFare(string[] TravelHistory);

        void AddZone(Zone zone);

        void RemoveZone(Zone zone);
    }
}
