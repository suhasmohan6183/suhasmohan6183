﻿using BusinessEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessService
{
    public class FareCalculator : IFareCalculator
    {
        List<Zone> ZoneList { get; set; }

        Zone FromZone { get; set; }

        public FareCalculator()
        {
            ZoneList = new List<Zone>();
        }
        private int CalculateFare(string Date, string Time,string FromZone, string ToZone)
        {

            this.FromZone =  ZoneList.FirstOrDefault(x => x.GetType().Name.Equals(FromZone, StringComparison.CurrentCultureIgnoreCase));
            if (this.FromZone != null)
            {
                return this.FromZone.GetFare(Date, Time, ToZone);
            }
            else
                return -1;
        }

        public int GetTotalFare(string[] TravelHistory)
        {
            
            Dictionary<DateTime, int> DailyTotalFare = new Dictionary<DateTime, int>();
            Dictionary<DateTime, int> WeeklyTotalFare = new Dictionary<DateTime, int>();
            Dictionary<DateTime, int> DailyCap = new Dictionary<DateTime, int>();
            Dictionary<DateTime, int> WeeklyCap = new Dictionary<DateTime, int>();

            foreach (var traveldetails in TravelHistory)
            {
                var strtraveldetails = traveldetails.Split(' ');
                var date = strtraveldetails[0];
                var time = strtraveldetails[1];
                var fromzone = strtraveldetails[2];
                var tozone = strtraveldetails[3];
                

                var Fare = CalculateFare(date, time, fromzone, tozone);

                var strdate = date.Split('/');
                var datetime = new DateTime(Convert.ToInt32(strdate[2]), Convert.ToInt32(strdate[1]), Convert.ToInt32(strdate[0]));

                this.PopulateFareCapDetails(this.FromZone.FareCapping.DailyFareCap,DailyCap, datetime, tozone);
                
                var weekstartdatetime = datetime.StartOfWeek(DayOfWeek.Monday);
                this.PopulateFareCapDetails(this.FromZone.FareCapping.WeeklyFareCap, WeeklyCap, weekstartdatetime, tozone);

                
                if(WeeklyTotalFare.ContainsKey(weekstartdatetime))
                {
                    var PossibleMaxWeeklyFare = WeeklyCap[weekstartdatetime] - WeeklyTotalFare[weekstartdatetime];
                    Fare = Fare < PossibleMaxWeeklyFare  ? Fare : PossibleMaxWeeklyFare;
                    if (DailyTotalFare.ContainsKey(datetime))
                    {
                        var PossibleMaxDailyFare = DailyCap[datetime] - DailyTotalFare[datetime];
                        Fare = Fare < PossibleMaxDailyFare  ? Fare : PossibleMaxDailyFare;
                        DailyTotalFare[datetime] = DailyTotalFare[datetime] + Fare;
                    }
                    else
                    {
                        DailyTotalFare.Add(datetime, Fare);
                    }
                    WeeklyTotalFare[weekstartdatetime] = WeeklyTotalFare[weekstartdatetime] + Fare;
                }
                else
                {
                    DailyTotalFare.Add(datetime, Fare);
                    WeeklyTotalFare.Add(weekstartdatetime, Fare);
                }
                
            }

            return DailyTotalFare.Values.Sum();
        }

        private void PopulateFareCapDetails(Dictionary<string,int> ZoneLevelFareCapDetails, Dictionary<DateTime, int> CustomerFareCap, 
                                            DateTime datetime, string tozone)
        {
            if (CustomerFareCap.ContainsKey(datetime))
            {
                if (ZoneLevelFareCapDetails[tozone] > CustomerFareCap[datetime])
                {
                    CustomerFareCap[datetime] = ZoneLevelFareCapDetails[tozone];
                }
            }
            else
            {
                CustomerFareCap.Add(datetime, ZoneLevelFareCapDetails[tozone]);
            }
        }

        public void AddZone(Zone zone)
        {
            ZoneList.Add(zone);
        }
        public void RemoveZone(Zone zone)
        {
            ZoneList.Remove(zone);
        }
    }
}
